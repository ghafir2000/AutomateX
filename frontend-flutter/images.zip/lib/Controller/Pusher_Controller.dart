// controllers/pusher_controller.dart
import 'package:get/get.dart';
import 'package:pusher_client_fixed/pusher_client_fixed.dart';
import 'dart:convert';
import 'package:intl/intl.dart';

class PusherController extends GetxController {
  final String apiKey;
  final String cluster;
  late PusherClient pusher;
  late Channel channel;

  var parsedMessages = <Map<String, dynamic>>[].obs;
  var isLoading = true.obs;

  PusherController({required this.apiKey, required this.cluster});

  @override
  void onInit() {
    super.onInit();
    _initPusher();
  }

  void _initPusher() {
    pusher = PusherClient(
      apiKey,
      PusherOptions(cluster: cluster),
      enableLogging: true,
    );

    pusher.connect();

    channel = pusher.subscribe('mqtt-channel');

    channel.bind('mqtt.message.received', (PusherEvent? event) {
      if (event != null && event.data != null) {
        try {
          final data = jsonDecode(event.data!);
          final innerJsonString = data['message'];
          final parsedMessage = jsonDecode(innerJsonString);

          parsedMessage['receivedAt'] = DateTime.now();
          parsedMessages.add(parsedMessage);
        } catch (e) {
          print("Error parsing message: $e");
        }
      }
    });

    isLoading.value = false;
  }

  String formatDateTime(DateTime dt) {
    return DateFormat('HH:mm:ss').format(dt);
  }

  @override
  void onClose() {
    pusher.unsubscribe('mqtt-channel');
    pusher.disconnect();
    super.onClose();
  }
}