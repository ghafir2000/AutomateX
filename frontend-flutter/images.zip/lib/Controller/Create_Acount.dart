import 'package:get/get.dart';

class CreateAccountController extends GetxController {
  var username = ''.obs;
  var passwordFirst = ''.obs;
  var passwordSecond = ''.obs;

  var obscureTextp1 = true.obs;
  var obscureTextp2 = true.obs;

  var pass = ''.obs;
  var  user = ''.obs;

  var minLength = false.obs;
  var hasNumber = false.obs;
  var passwordsMatch = false.obs;

  void validatePassword(String value) {
    passwordFirst.value = value;
    minLength.value = value.length >= 8;
    hasNumber.value = value.contains(RegExp(r'[0-9]'));
    passwordsMatch.value = passwordFirst.value == passwordSecond.value;
  }
  void validatePasswordConfirmation(String value) {
    passwordSecond.value = value;
    passwordsMatch.value = passwordFirst.value == value;
  }

  void toggleVisibilityp1() {obscureTextp1.toggle();}
  void toggleVisibilityp2() {obscureTextp2.toggle();}


  bool get isValid => minLength.value && hasNumber.value && passwordsMatch.value;

  bool saveCredentials() {
    if (isValid) {
      user.value = username.value;
      pass.value = passwordSecond.value;
      return true;
    }
    return false;
  }

}
