import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../Controller/CheckBoxController.dart';
import '../Controller/Check_Acount.dart';
import '../Controller/Create_Acount.dart';
import '../Controller/Pusher_Controller.dart';
import 'Home_Page.dart';
import 'package:molten_navigationbar_flutter/molten_navigationbar_flutter.dart';

import 'chat_table.dart';



final CheckAccount controllercheck = Get.put(CheckAccount());
final CheckBoxController contrllercheckbox = Get.put(CheckBoxController());
final CreateAccountController controllercreateaccount = Get.put(CreateAccountController());
final pusherController = Get.find<PusherController>(tag: 'pusher');




class SmartIncubater extends StatefulWidget {
  const SmartIncubater({super.key});



  @override
  _SmartIncubaterState createState() => _SmartIncubaterState();
}

class _SmartIncubaterState extends State<SmartIncubater> {
  int _selectedIndex = 0;
  final PageController _pageController = PageController();


  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(

        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          shadowColor: Colors.blueAccent,
          actions: const [],
          leading: Builder(
            builder: (context) {
              return IconButton(
                icon: const Icon(Icons.list),
                onPressed: () => Scaffold.of(context).openDrawer(),
              );
            },
          ),
          shape: LinearBorder.bottom(
            alignment: 30,
            size: 1,
            side: const BorderSide(
              width: 1,
              color: Colors.red,
            ),
          ),
          centerTitle: true,
          title: const Column(
            children: [
              Text("Controller Page"),
            ],
          ),
        ),
        drawer: Drawer(
          child: ListView(
            children: [
              DrawerHeader(
                decoration: const BoxDecoration(
                    color: Colors.indigo,
                    borderRadius: BorderRadius.all(Radius.circular(20))),
                child: Row(
                  children: [
                    Container(
                      width: 50,
                      height: 50,
                      decoration: const BoxDecoration(
                          gradient: SweepGradient(colors: Colors.primaries),
                          shape: BoxShape.circle),
                      child: Center(
                        child: Container(
                          width: 47,
                          height: 47,
                          decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              image: DecorationImage(image: AssetImage("images/ff.png"), fit: BoxFit.cover)),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 75,
                      width: 200,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text("${controllercreateaccount.user}"),
                            ],
                          ),
                          const SizedBox(height: 5),
                          const Row(
                            children: [
                              SizedBox(width: 10),
                              Text("Phone Number"),
                            ],
                          ),
                          const SizedBox(height: 5),
                          const Row(
                            children: [
                              Text("Project type"),
                            ],
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
              ListTile(
                title: const Row(
                  children: [
                    Icon(Icons.settings),
                    SizedBox(width: 10),
                    Text("setting"),
                  ],
                ),
                onTap: () {},
              ),
              ListTile(
                title: const Row(
                  children: [
                    Icon(Icons.logout),
                    SizedBox(width: 10),
                    Text("Logout"),
                  ],
                ),
                onTap: () {
                  Get.offAll(const HomePage());
                  controllercheck.logout();
                },
                splashColor: Colors.green,
              ),
              ListTile(
                title: const Row(
                  children: [
                    Icon(Icons.info_outline),
                    SizedBox(width: 10),
                    Text("About Us"),
                  ],
                ),
                onTap: () {},
                splashColor: Colors.green,
                subtitle: const Text(" لمحة عن الفريق ", textDirection: TextDirection.rtl),
              ),
            ],
          ),
        ),
        body:Stack(
          children: [
            PageView(

            clipBehavior: Clip.hardEdge,
            controller: _pageController,
            onPageChanged: (index) {
              setState(() {
                _selectedIndex = index;
              });
            },
            children: [
              ListView(
                children: [
                  PusherTableView(
                    apiKey: "cb788493e8aa5bf58a70",
                    cluster: "mt1",
                  )
                ],
              ),
              Container(
                width: Get.width,
                height: Get.height,
                color: Colors.white,
                child: const Center(child: Text("page2")),
              ),
              Container(
                width: Get.width,
                height: Get.height,
                color: Colors.white,
                child: const Center(child: Text("page3")),
              ),
              Container(
                width: Get.width,
                height: Get.height,
                color: Colors.white,
                child: const Center(child: Text("page4")),
              ),
            ],
          ),
            Positioned(
            bottom: 0,
            right: 0,
            left: 0,

            child: MoltenBottomNavigationBar(

                domeWidth: 300,
                domeCircleSize: 50,
                domeHeight: 20,
                domeCircleColor: Colors.white30,


                // borderSize: 1,
                barHeight: 40,
                borderRaduis: const BorderRadius.vertical(top: Radius.circular(10)),
                curve: Curves.easeOutSine,
                borderColor: Colors.black,
                selectedIndex: _selectedIndex,
                onTabChange: (index){
                  setState(() {
                    _selectedIndex=index;
                    _pageController.jumpToPage(index);
                  }
                  );
                },
                barColor: Colors.blueAccent,
                tabs: [
                  MoltenTab(
                    unselectedColor: Colors.grey,
                    selectedColor: Colors.blue,
                    icon: Icon(Icons.home),),
                  MoltenTab(selectedColor: Colors.red,unselectedColor: Colors.grey,icon: Icon(Icons.favorite,)),
                  MoltenTab(selectedColor:Colors.yellow,unselectedColor: Colors.grey,icon: Icon(Icons.notifications,)),
                  MoltenTab(selectedColor: Colors.green,unselectedColor: Colors.grey,icon: Icon(Icons.person,),)

                ]
            ),
          ),
          ],
        ),

      ),
    );
  }
}
